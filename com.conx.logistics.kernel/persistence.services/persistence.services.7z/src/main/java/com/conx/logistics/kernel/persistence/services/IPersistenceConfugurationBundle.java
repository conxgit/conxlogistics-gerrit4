package com.conx.logistics.kernel.persistence.services;

import java.util.Map;

import org.osgi.framework.Bundle;

public interface IPersistenceConfugurationBundle {
	public Bundle getBundle();
}
